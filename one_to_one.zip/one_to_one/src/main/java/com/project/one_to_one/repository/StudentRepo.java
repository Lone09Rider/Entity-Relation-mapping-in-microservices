package com.project.one_to_one.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.one_to_one.entity.Student;

/**
 * StudentRepo
 */
public interface StudentRepo extends JpaRepository<Student, Integer> {}