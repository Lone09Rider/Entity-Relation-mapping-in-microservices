package com.project.one_to_one;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.project.one_to_one.entity.Laptop;
import com.project.one_to_one.entity.Student;
import com.project.one_to_one.repository.StudentRepo;

@SpringBootApplication
public class OneToOneApplication implements CommandLineRunner {

	@Autowired
	private StudentRepo repo;

	private Logger logger = LoggerFactory.getLogger(OneToOneApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(OneToOneApplication.class, args);
	}

	// override run method 
	@Override
	public void run(String... args) throws Exception {
		Student student = new Student();
		student.setStudentName("Chikoo");
		student.setAbout("I am a Software Engineer");

		Laptop laptop = new Laptop();
		laptop.setModelNumber("HP59");
		laptop.setBrand("HP");
		laptop.setStudent(student);

		// manually save laptop by creating LaptopRepo or this -> see laptop and student
		student.setLaptop(laptop);

		Student save = repo.save(student);

		logger.info("Student saved : {}", save.getStudentName());
		logger.info("Laptop Saved with Model {} and Brand {}", laptop.getModelNumber(), laptop.getBrand());
	}

}
