package com.project.many_to_many;

// import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.project.many_to_many.entity.Category;
import com.project.many_to_many.entity.Product;
import com.project.many_to_many.repository.CategoryRepo;
import com.project.many_to_many.repository.ProductRepo;

@SpringBootApplication
public class ManyToManyApplication implements CommandLineRunner{

	@Autowired
	private CategoryRepo categoryRepo;
	@Autowired
	private ProductRepo proRepo;

	public static void main(String[] args) {
		SpringApplication.run(ManyToManyApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// Product product1 = new Product();
		// product1.setPId("pid1");
		// product1.setPName("product1");

		// Product product2 = new Product();
		// product2.setPId("pid2");
		// product2.setPName("product2");

		// Product product3 = new Product();
		// product3.setPId("pid3");
		// product3.setPName("product3");

		// Category category1 = new Category();
		// category1.setCid("cid1");
		// category1.setTitle("category1");

		// Category category2 = new Category();
		// category2.setCid("cid2");
		// category2.setTitle("category2");

		// List<Product> category1Products = category1.getProducts();
		// category1Products.add(product1);
		// category1Products.add(product2);
		// category1Products.add(product3);

		// List<Product> category2Products = category2.getProducts();
		// category2Products.add(product3);
		// category2Products.add(product2);

		// categoryRepo.save(category1);
		// categoryRepo.save(category2);
		
		Category category = categoryRepo.findById("cid2").get();
		System.out.println(category.getProducts().size());

		Product product = proRepo.findById("pid3").get();
		System.out.println(product.getCategories().size());
	}

}
