package com.project.many_to_many.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.many_to_many.entity.Product;

public interface ProductRepo extends JpaRepository<Product, String> {
    
}
