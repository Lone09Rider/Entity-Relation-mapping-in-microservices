package com.project.onetomany;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.project.onetomany.Entity.Address;
import com.project.onetomany.Entity.Laptop;
import com.project.onetomany.Entity.Student;
import com.project.onetomany.Repository.StudentRepo;
import java.util.ArrayList;

@SpringBootApplication
public class OnetomanyApplication implements CommandLineRunner {

	@Autowired
	private StudentRepo repo;

	private Logger logger = LoggerFactory.getLogger(OnetomanyApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(OnetomanyApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Student student = new Student();
		student.setStudentName("Kokila");
		student.setAbout("I am a Software Engineer Trainee");

		Laptop laptop = new Laptop();
		laptop.setLaptopBrand("Lenovo");
		laptop.setLaptopModel("Ideapad 320");

		Address address1 = new Address();
		address1.setCity("Pune");
		address1.setStreet("Katraj");
		address1.setCountry("India");
		address1.setStudent(student);

		Address address2 = new Address();
		address2.setCity("Chennai");
		address2.setStreet("Nataraj Nagar");
		address2.setCountry("India");
		address2.setStudent(student);

		List<Address> addresses = new ArrayList<>();
		addresses.add(address2);
		addresses.add(address1);

		laptop.setStudent(student);
		student.setLaptop(laptop);
		student.setAddressList(addresses);
		
		

		Student save = repo.save(student);

		logger.info("Student {} added.", save.getStudentName());
		logger.info("Laptop {} added.", laptop.getLaptopBrand());
	}

}
