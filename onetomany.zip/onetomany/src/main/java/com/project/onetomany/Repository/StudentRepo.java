package com.project.onetomany.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.onetomany.Entity.Student;

public interface StudentRepo extends JpaRepository<Student, Integer> {
    
}
